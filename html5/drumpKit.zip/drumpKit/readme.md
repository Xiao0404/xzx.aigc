# 全球顶级html5 入门案例

- html5
    富应用 rich application
    html 结构
    css  样式
    js   交互
    网页 -》 应用 (app一样)   rich  sound  + video (B站) + canvas (弹幕) + LBS (定位，美团) + 触摸 

- 注重基础
    - 大厂面试细节
        1.

## 快
    - emeet 输入语法 vscode 内置 css selector
    - 思路快，优秀的编程习惯
    - 加载速度快  css在头部，js在尾部 为0.1s而努力
    - css的布局方案 快速选择flex
    - css emmet 

- 先解析html结构
- 解耦 模块化  module 样式
    css 放在头部 网页每块0.1s,用户多1000万
- js 
    没有必要那么早的加载 尾部 script会阻塞页面加载

- 如何快速实现水平垂直居中
    - 父元素flex
    - align-items: center;
        justify-content: center;

- html5 仿真